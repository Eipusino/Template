package heavyindustry.core;

import heavyindustry.util.ReflectImpl;

import java.lang.reflect.AccessibleObject;

public class DefaultImpl implements ReflectImpl {
	@Override
	public void setOverride(AccessibleObject override) {
		// not
	}

	@Override
	public void setPublic(Class<?> type) {
		// not
	}
}
