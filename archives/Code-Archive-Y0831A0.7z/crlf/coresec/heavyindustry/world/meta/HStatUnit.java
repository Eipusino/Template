package heavyindustry.world.meta;

import mindustry.world.meta.StatUnit;

public final class HStatUnit {
	public static StatUnit
			upTo = new StatUnit("hi-up-to"),
			threshold = new StatUnit("hi-threshold");

	private HStatUnit() {}
}
