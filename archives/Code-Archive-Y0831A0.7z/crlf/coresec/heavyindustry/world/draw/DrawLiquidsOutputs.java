package heavyindustry.world.draw;

import arc.Core;
import arc.graphics.g2d.Draw;
import arc.graphics.g2d.TextureRegion;
import arc.util.Eachable;
import mindustry.entities.units.BuildPlan;
import mindustry.gen.Building;
import mindustry.world.Block;
import mindustry.world.blocks.production.GenericCrafter;
import mindustry.world.draw.DrawLiquidOutputs;

public class DrawLiquidsOutputs extends DrawLiquidOutputs {
	@Override
	public void draw(Building build) {
		if (build.block instanceof GenericCrafter crafter) {
			if (crafter.outputLiquids == null) return;

			for (int i = 0; i < crafter.outputLiquids.length; i++) {
				int side = i < crafter.liquidOutputDirections.length ? crafter.liquidOutputDirections[i] : -1;
				if (side != -1) {
					int realRot = (side + build.rotation) % 4;
					Draw.rect(liquidOutputRegions[realRot > 1 ? 1 : 0][i], build.x, build.y, realRot * 90);
				}
			}
		}
	}

	@Override
	public void drawPlan(Block block, BuildPlan plan, Eachable<BuildPlan> list) {
		if (block instanceof GenericCrafter crafter) {
			if (crafter.outputLiquids == null) return;

			for (int i = 0; i < crafter.outputLiquids.length; i++) {
				int side = i < crafter.liquidOutputDirections.length ? crafter.liquidOutputDirections[i] : -1;
				if (side != -1) {
					int realRot = (side + plan.rotation) % 4;
					Draw.rect(liquidOutputRegions[realRot > 1 ? 1 : 0][i], plan.drawx(), plan.drawy(), realRot * 90);
				}
			}
		}
	}

	@Override
	public void load(Block block) {
		if (block instanceof GenericCrafter crafter) {
			if (crafter.outputLiquids == null) return;

			liquidOutputRegions = new TextureRegion[2][crafter.outputLiquids.length];
			for (int i = 0; i < crafter.outputLiquids.length; i++) {
				for (int j = 1; j <= 2; j++) {
					liquidOutputRegions[j - 1][i] = Core.atlas.find(block.name + "-" + i + "-output" + j);
				}
			}
		}
	}
}
