package heavyindustry.gen;

public interface ChainMechc extends Chainedc {
	float baseRotation();

	float walk();

	void baseRotation(float value);

	void walk(float value);
}
