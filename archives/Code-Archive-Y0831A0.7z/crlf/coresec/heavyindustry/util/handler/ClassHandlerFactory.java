package heavyindustry.util.handler;

public interface ClassHandlerFactory {
	ClassHandler getHandler(Class<?> modMain);
}
