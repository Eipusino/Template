package heavyindustry.gen;

public interface Corec extends BaseUnitc {
}
