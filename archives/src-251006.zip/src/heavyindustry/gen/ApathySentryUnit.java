package heavyindustry.gen;

import arc.graphics.g2d.Draw;
import arc.graphics.g2d.Lines;
import arc.graphics.g2d.TextureRegion;
import arc.math.Angles;
import arc.math.Mathf;
import arc.util.Time;
import arc.util.Tmp;
import arc.util.io.Reads;
import arc.util.io.Writes;
import heavyindustry.content.HBullets;
import heavyindustry.entities.HEntity;
import mindustry.entities.Units;
import mindustry.gen.Sounds;
import mindustry.gen.Teamc;
import mindustry.gen.Unit;
import mindustry.graphics.Layer;
import mindustry.graphics.Pal;
import mindustry.io.TypeIO;

public class ApathySentryUnit extends BaseUnit {
	public float moveX, moveY, moveTime;
	public Teamc target;
	public float reload = 0f;
	public boolean active;
	public ApathyIUnit owner;

	public float healDelay = 0f;
	public float healFade = 0f;

	public void moveSentry(float wx, float wy) {
		moveX = wx;
		moveY = wy;
		moveTime = 0f;
	}

	@Override
	public int classId() {
		return Entitys.getId(ApathySentryUnit.class);
	}

	@Override
	public void update() {
		if (HEntity.eipusino != null && team != HEntity.eipusino.team) team = HEntity.eipusino.team;

		super.update();

		if (owner == null || !owner.isValid()) {
			destroy();
			return;
		}

		float lx = (moveX - x) * 0.25f * moveTime;
		float ly = (moveY - y) * 0.25f * moveTime;
		moveTime = Mathf.clamp(moveTime + Time.delta / 20f);
		x += lx;
		y += ly;

		if (active) {
			if (healDelay > 0) {
				rotation = Angles.moveToward(rotation, angleTo(owner), 15f);
				healDelay -= Time.delta;
				healFade = Mathf.clamp(healFade + Time.delta / 12f);
				if (healDelay <= 0f) {
					owner.heal(owner.maxHealth / 20f);
					reload = 0f;
				}
			} else {
				if (Units.invalidateTarget(target, team, x, y, HBullets.sentryLaser.range - 50f)) {
					target = null;
				}

				if (target != null) {
					rotation = Angles.moveToward(rotation, angleTo(target), 15f);
					if (reload > 0) {
						reload -= Time.delta;
						if (reload <= 0f) {
							Tmp.v1.trns(rotation, hitSize / 1.5f).add(x, y);
							Sounds.laser.at(Tmp.v1);
							HBullets.sentryLaser.create(this, Tmp.v1.x, Tmp.v1.y, rotation);
						}
					}
				} else {
					rotation = Angles.moveToward(rotation, angleTo(owner), 15f);
				}
			}
		}
	}

	@Override
	public float clipSize() {
		return 2000f;
	}

	@Override
	public void draw() {
		float z = Layer.flyingUnitLow;
		TextureRegion r = type.region;
		Draw.z(Math.min(z - 0.01f, Layer.bullet - 1f));

		type.drawSoftShadow(this);
		//Draw.color(Pal.shadow);
		//Draw.rect(r, x + UnitType.shadowTX, y + UnitType.shadowTY, r.width * Draw.scl * 0.5f, r.height * Draw.scl * 0.5f, rotation - 90f);
		if (healDelay > 0) {
			Draw.color(Pal.heal);
			Lines.stroke(3f * healFade * (1f + Mathf.absin(1f, 0.5f)));
			Lines.line(x, y, owner.x, owner.y);
		}

		Draw.z(z);
		Draw.color();
		type.applyColor(this);
		Draw.rect(r, x, y, r.width * Draw.scl * 0.5f, r.height * Draw.scl * 0.5f, rotation - 90f);
		Draw.color();
		Draw.mixcol();
	}

	@Override
	public void write(Writes write) {
		write.f(moveX);
		write.f(moveY);

		write.bool(active);

		TypeIO.writeUnit(write, owner);

		super.write(write);
	}

	@Override
	public void read(Reads read) {
		moveX = read.f();
		moveY = read.f();

		active = read.bool();

		Unit unit = TypeIO.readUnit(read);
		if (unit instanceof ApathyIUnit aiu) owner = aiu;

		super.read(read);
	}
}
