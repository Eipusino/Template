package heavyindustry.gen;

import arc.Core;
import arc.graphics.Color;
import arc.graphics.g2d.Draw;
import arc.graphics.g2d.Fill;
import arc.math.Angles;
import arc.math.Mathf;
import arc.math.Rand;
import arc.math.geom.Vec2;
import arc.struct.Seq;
import arc.util.Time;
import arc.util.Tmp;
import arc.util.io.Reads;
import arc.util.io.Writes;
import heavyindustry.ai.ApathyIAI;
import heavyindustry.ai.BaseCommand;
import heavyindustry.content.HFx;
import heavyindustry.content.HUnitTypes;
import heavyindustry.entities.HEntity;
import heavyindustry.entities.shift.PrismShift;
import heavyindustry.entities.shift.ShiftHandler;
import heavyindustry.entities.shift.StrongLaserShift;
import heavyindustry.graphics.Drawn;
import heavyindustry.graphics.HPal;
import heavyindustry.type.unit.ApathyUnitType;
import heavyindustry.util.Utils;
import mindustry.Vars;
import mindustry.audio.SoundLoop;
import mindustry.content.Fx;
import mindustry.gen.Bullet;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Hitboxc;
import mindustry.gen.Unit;
import mindustry.graphics.Layer;
import mindustry.io.TypeIO;
import mindustry.type.UnitType;

public class ApathyIUnit extends BaseUnit {
	public static final float shieldMaxHealth = 10000f;

	public ShiftHandler current, last;
	public float shiftProgress = 0f;
	public boolean shifting = false;

	public float heartBeatTimer = 0f;
	public float stress = 0f;
	public float conflict = 0f;

	public float shieldHealth = shieldMaxHealth, shieldStun = 0f;
	public float extraShiftSpeed = 1f;

	public float shiftRotation = 0f;
	public float deathTimer = 0f;

	public int deathSoundIdx = 0;
	public int shiftSound = -1;

	public Seq<ApathySentryUnit> sentries = new Seq<>(ApathySentryUnit.class);
	public boolean createSentries = false;
	public int sentryPosition;
	public float sentrySpawnDelay, sentrySpawnDelay2, sentryRepositionTime;

	public float sentryHealTime = 0f;

	@Override
	public int classId() {
		return Entitys.getId(ApathyIUnit.class);
	}

	@Override
	public void setType(UnitType type) {
		super.setType(type);

		ApathyUnitType u = (ApathyUnitType) type;
		current = u.handlers.get(0);
	}

	@Override
	public void collision(Hitboxc other, float ox, float oy) {
		super.collision(other, ox, oy);
		if (other instanceof Bullet b) {
			float dps = b.type.estimateDPS();
			if (dps <= 0f) return;

			if (current.critPoints != null) {
				float[] crit = current.critPoints;
				for (int i = 0; i < current.critPoints.length; i += 2) {
					float angle = rotation + crit[i];
					float rotTo = angleTo(b);
					float dst = dst(b);
					float at = Mathf.angle(dst, 5f);
					//float at = Mathf.angle(10f, dst);
					if (Angles.within(angle, rotTo, crit[i + 1]) && Angles.within(rotTo, b.rotation() + 180f, at) && (b.vel.len() > 24f || dst > type.hitSize)) {
						//Fx.scatheExplosion.at(x, y);
						//Log.info(at);
						damagePierce(dps * 10f);
						stress += dps / 2f;

						if (controller instanceof ApathyIAI ai) ai.criticalHit(dps * 10f);
						else if (controller instanceof BaseCommand command && command.controller() instanceof ApathyIAI ai) ai.criticalHit(dps * 10f);

						if (dps * 10 > 500000f) HFx.apathyCrit.at(x, y, rotation, this);
						break;
					}
				}
			}
			stress += dps / 60f;
			shieldHealth -= (b.type.estimateDPS() / 2f);
		}
	}

	@Override
	public void rawDamage(float amount) {
		super.rawDamage(amount);

		if (sentryHealTime > 1) {
			sentryHealTime -= Math.min(10f, amount / 60f);
			if (sentryHealTime < 1) sentryHealTime = 1f;
		}
	}

	public float getStressScaled() {
		return Math.min(Math.max(stress / 100f, Mathf.clamp(1 - (health / maxHealth) * 2)), 2f);
	}

	public float getShieldRadius() {
		return ((shieldHealth / shieldMaxHealth) * (current.shieldRadius - 200f)) + 200f;
	}

	@Override
	public void update() {
		if (HEntity.eipusino != null && team != HEntity.eipusino.team) team = HEntity.eipusino.team;

		if (health < 0f) health = 0f;
		super.update();
		float stressScaled = getStressScaled();

		if (shifting && last != null) {
			float scl = current.stressAffected ? (1 + stressScaled) : 1f;
			shiftProgress = Mathf.clamp(shiftProgress + (1f / current.shiftDuration) * Time.delta * scl * extraShiftSpeed);
			//shiftProgress = Mathf.clamp(shiftProgress + 0.005f * Time.delta);
			//last.updateShift(this, 1 - shiftProgress, true);
			//current.updateShift(this, shiftProgress, false);
			float curve = Mathf.curve(shiftProgress, 0, current.lastShiftEnd);

			last.updateShift(this, 1 - curve, true);
			current.updateShift(this, shiftProgress, false);

			if (shiftProgress >= 1) {
				shifting = false;
				extraShiftSpeed = 1f;

				if (shiftSound != -1) {
					Core.audio.stop(shiftSound);
					shiftSound = -1;
				}
				if (current instanceof PrismShift) HSounds.clang.at(x, y);
			}
		} else {
			current.update(this);
			current.updateShift(this, 1f, false);
		}
		if (dead) {
			if (deathTimer <= 0f) {
				//HSounds.apathyDeathCry.at(x, y, 1, 3);
				HSounds.apathyDeathCry.play(2f);
			}
			deathTimer += Time.delta;
			if (deathTimer > 45f) {
				Rand rand = Utils.rand(id * 531l);

				int count = (int) (Mathf.pow((deathTimer - 45) / (4f * 60f - 45), 2) * 16) + 1;
				for (int i = 0; i < count; i++) {
					float fin = (i / 16f) * 0.5f + 0.5f;

					Vec2 v = Tmp.v1.trns(rand.random(360f), rand.random(hitSize / 2));
					Color tc = Tmp.c1;
					tc.r = rand.random(80f, 120f) * fin;
					tc.g = rand.random(380f, 420f) * fin;

					if (i >= deathSoundIdx) {
						HSounds.apathyBleed.at(x + v.x, y + v.y, Mathf.random(0.9f, 1.1f), 1f);
						deathSoundIdx++;
					}
				}
			}
			if (deathTimer > 4f * 60f) {
				Call.unitDestroy(id);
			}
		}

		heartBeatTimer += ((1f + stressScaled / 2f) / 40f) * Time.delta;
		if (heartBeatTimer >= Math.max(2.5f - stressScaled * 0.75f, 1f)) {
			heartBeatTimer = 0f;
		}

		if (stress > 0f) {
			float t = conflict > 0f ? 1000f : 70f;
			stress -= (5f + stress / t) * Time.delta;
			if (stress < 0f) {
				stress = 0f;
			}
		}
		if (conflict > 0) conflict -= Time.delta;

		if (shieldStun <= 0f) {
			if (shieldHealth < shieldMaxHealth) {
				shieldHealth += (25f + Mathf.clamp(stress / 5f, 0f, 100f)) * Time.delta;
				if (shieldHealth > shieldMaxHealth) {
					shieldHealth = shieldMaxHealth;
				}
			}
		} else {
			shieldStun -= Time.delta;
			if (shieldStun <= 0f) {
				shieldHealth = shieldMaxHealth / 2f;
			}
		}
		if (shieldStun > 0 || health < (maxHealth / 3f)) {
			if (sentries.size < 8 && !createSentries && sentrySpawnDelay2 <= 0f) {
				createSentries = true;
				sentryPosition = sentries.size;
				repositionSentries(false);
			}
		}

		updateSentries();
	}

	public void updateSentries() {
		//if (sentrySpawnDelay2 > 0) createSentries = false;
		if (createSentries && sentrySpawnDelay2 <= 0f) {
			if (sentrySpawnDelay <= 0f) {
				if (sentryHealTime <= 0f || sentries.isEmpty()) {
					sentryHealTime = 30f * 60f;
				} else {
					sentryHealTime = Math.min(30f * 60, sentryHealTime + 15f);
				}

				Vec2 v = Tmp.v1.trns((360f / 16) * sentryPosition, 200f).add(x, y);

				ApathySentryUnit s = (ApathySentryUnit) HUnitTypes.apathySentry.create(team);
				s.set(v.x, v.y);
				s.moveSentry(v.x, v.y);
				s.rotation = (360f / 16) * sentryPosition;
				s.active = false;
				s.owner = this;

				s.add();
				HFx.bigLaserFlash.at(s.x, s.y);
				sentries.add(s);

				sentryPosition++;
				if (sentryPosition >= 16) {
					createSentries = false;
					sentrySpawnDelay2 = 3f * 60f;
					repositionSentries(false);
				} else {
					sentrySpawnDelay = 6f;
				}
			}
			sentrySpawnDelay -= Time.delta;
		}
		if (sentries.size < 8) sentrySpawnDelay2 -= Time.delta;

		sentries.removeAll(s -> !s.isValid());

		boolean heal = false;

		if (sentryHealTime > 0) {
			sentryHealTime -= Time.delta;
			if (sentryHealTime <= 0f) {
				heal = true;

				createSentries = false;
				sentrySpawnDelay = 0f;
			}
		}

		boolean allHealing = false;

		if (controller instanceof ApathyIAI ai) {
			for (ApathySentryUnit s : sentries) {
				s.target = ai.strongest;
				allHealing |= s.healDelay > 0;
			}

			if (sentries.any() && !createSentries && !allHealing) {
				sentryRepositionTime += Time.delta;
				if (sentryRepositionTime >= 3f * 60f || heal) {
					repositionSentries(heal);
					sentryRepositionTime = 0f;
				}
			}
		} else if (controller instanceof BaseCommand command && command.controller() instanceof ApathyIAI ai) {
			for (ApathySentryUnit s : sentries) {
				s.target = ai.strongest;
				allHealing |= s.healDelay > 0;
			}

			if (sentries.any() && !createSentries && !allHealing) {
				sentryRepositionTime += Time.delta;
				if (sentryRepositionTime >= 3f * 60f || heal) {
					repositionSentries(heal);
					sentryRepositionTime = 0f;
				}
			}
		}
	}

	public void repositionSentries(boolean heal) {
		int idx = 0;
		//ApathyIAI ai = (ApathyIAI) controller;

		for (ApathySentryUnit s : sentries) {
			if (s.healDelay > 0) continue;
			if (!heal) {
				if (createSentries) {
					Tmp.v1.trns((360f / 16) * idx, 200f).add(x, y);
					s.active = false;
				} else {
					Tmp.v1.trns(Mathf.random(360f), 600f * Mathf.sqrt(Mathf.random(200f / 600f, 1f))).add(x, y);
					s.active = true;
					if (s.reload <= 0f) s.reload = 6f * idx + 20f;
				}
				//s.target = ai.strongest;
				s.moveSentry(Tmp.v1.x, Tmp.v1.y);
			} else {
				s.healDelay = 180f + idx * 10f;
				s.active = true;
			}

			idx++;
		}
	}

	@Override
	public void destroy() {
		super.destroy();

		//HSounds.apathyDeath.at(x, y, 1, 3);
		HSounds.apathyDeath.play(1f);
	}

	public float getHeartBeat() {
		if (heartBeatTimer > 1) return 0f;
		float f = heartBeatTimer;
		float p = Mathf.curve(f, 0.1f, 0.25f);
		p = p * p * 180f;
		p = Mathf.sinDeg(p) * 0.12f;

		float qrs = Mathf.curve(f, 0.39f, 0.61f);
		float w = Mathf.sinDeg((qrs * (360 + 180)) - 180);
		w = w * Mathf.sinDeg(Mathf.pow(qrs, 1.25f) * 180);
		w *= w > 0 ? 0.9f : 0.5f;

		float t = Mathf.curve(f, 0.70f, 0.85f);
		t = t * t * 180;
		t = Mathf.sinDeg(t) * 0.12f;

		return p + w + t;
	}

	@Override
	public void draw() {
		//super.draw();
		boolean isPayload = !isAdded();
		float z = isPayload ? Draw.z() : elevation > 0.5f ? (type.lowAltitude ? Layer.flyingUnitLow : Layer.flyingUnit) : type.groundLayer + Mathf.clamp(hitSize / 4000f, 0, 0.01f);

		/*if (!isPayload && (isFlying())) {
			Draw.z(Math.min(Layer.darkness, z - 1f));
			type.drawShadow(this);
		}*/
		Draw.z(Math.min(z - 0.01f, Layer.bullet - 1f));

		type.drawSoftShadow(this);

		Draw.z(z);
		float hb = 1 + getHeartBeat() * 0.25f;

		Draw.color(HPal.primary);
		Fill.circle(x, y, 5f * hb);
		Draw.color();
		Fill.circle(x, y, 3.75f * hb);

		//Draw.mixcol(Tmp.c1, Math.max(unit.hitTime, !healFlash ? 0f : Mathf.clamp(unit.healTime)));
		//Draw.mixcol(Color.white, hitTime);
		type.applyColor(this);
		if (!dead) {
			if (shifting && last != null) {
				float curve = Mathf.curve(shiftProgress, 0, current.lastShiftEnd);

				last.drawOut(this, curve);
				current.drawIn(this, shiftProgress);
			} else {
				current.drawFull(this);
			}
		} else {
			Drawn.drawDeath(type.region, 43141 + id * 133, x, y, rotation, Mathf.clamp(deathTimer / 36), Mathf.clamp((deathTimer - 60f) / (3f * 60f)));
		}
		Draw.mixcol();
	}

	public void switchShift(ShiftHandler h) {
		if (h != current) {
			float scl = h.stressAffected ? (1 + getStressScaled()) : 1f;
			//float scl = current.stressAffected ? (1 + stressScaled) : 1f;
			//shiftProgress = Mathf.clamp(shiftProgress + (1f / current.shiftDuration) * Time.delta * scl * extraShiftSpeed);
			shiftSound = h.shiftSound.at(x, y, scl * extraShiftSpeed);
			if (h instanceof StrongLaserShift) shiftSound = -1;
		}

		shiftProgress = 0;
		last = current;
		current = h;
		shifting = true;
	}

	@Override
	public void add() {
		if (added || count() >= 1 || HEntity.apathy != null) return;

		HEntity.apathy = this;

		index__all = Groups.all.addIndex(this);
		index__unit = Groups.unit.addIndex(this);
		index__sync = Groups.sync.addIndex(this);
		index__draw = Groups.draw.addIndex(this);

		added = true;

		updateLastPosition();

		team.data().updateCount(type, 1);
	}

	@Override
	public void remove() {
		if (!added) return;

		HEntity.apathy = null;

		Groups.all.removeIndex(this, index__all);
		index__all = -1;
		Groups.unit.removeIndex(this, index__unit);
		index__unit = -1;
		Groups.sync.removeIndex(this, index__sync);
		index__sync = -1;
		Groups.draw.removeIndex(this, index__draw);
		index__draw = -1;

		added = false;

		if (Vars.net.client()) {
			Vars.netClient.addRemovedEntity(id());
		}

		team.data().updateCount(type, -1);
		controller.removed(this);

		if (trail != null && trail.size() > 0) {
			Fx.trailFade.at(x, y, trail.width(), type.trailColor == null ? team.color : type.trailColor, trail.copy());
		}

		if (index__all != -1 ) {
			if (controller instanceof ApathyIAI ai && ai.sounds != null) {
				for (SoundLoop sl : ai.sounds) {
					sl.stop();
				}
			} else if (controller instanceof BaseCommand command && command.controller() instanceof ApathyIAI ai) {
				for (SoundLoop sl : ai.sounds) {
					sl.stop();
				}
			}
		}
	}

	@Override
	public void write(Writes write) {
		write.f(shiftProgress);
		write.bool(shifting);
		write.f(stress);
		write.f(shieldHealth);
		write.f(shiftRotation);
		write.bool(createSentries);

		writeShiftHandler(write);
		writeApathySentry(write);

		super.write(write);
	}

	@Override
	public void read(Reads read) {
		shiftProgress = read.f();
		shifting = read.bool();
		stress = read.f();
		shieldHealth = read.f();
		shiftRotation = read.f();
		createSentries = read.bool();

		readShiftHandler(read);
		readApathySentry(read, true);

		super.read(read);
	}

	@Override
	public void writeSync(Writes write) {
		write.f(shiftProgress);
		write.bool(shifting);
		write.f(stress);
		write.f(shieldHealth);
		write.f(shiftRotation);
		write.bool(createSentries);

		writeShiftHandler(write);
		writeApathySentry(write);

		super.writeSync(write);
	}

	@Override
	public void readSync(Reads read) {
		shiftProgress = read.f();
		shifting = read.bool();
		stress = read.f();
		shieldHealth = read.f();
		shiftRotation = read.f();
		createSentries = read.bool();

		readShiftHandler(read);
		readApathySentry(read, false);

		super.readSync(read);
	}

	protected void writeApathySentry(Writes write) {
		int size = sentries.size;

		write.i(size);

		for (int i = 0; i < size; i++) {
			Unit unit = sentries.get(i);

			TypeIO.writeUnit(write, unit);
		}
	}

	protected void readApathySentry(Reads read, boolean map) {
		int size = read.i();

		for (int i = 0; i < size; i++) {
			Unit unit = TypeIO.readUnit(read);

			if (unit instanceof ApathySentryUnit asu && (map || !sentries.contains(asu, true))) sentries.add(asu);
		}
	}

	protected void writeShiftHandler(Writes write) {
		// TODO What shall I do?
	}

	protected void readShiftHandler(Reads read) {
		// TODO What shall I do?
	}
}
