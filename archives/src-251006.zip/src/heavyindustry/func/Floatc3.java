package heavyindustry.func;

public interface Floatc3 {
	void get(float p1, float p2, float p3);
}
