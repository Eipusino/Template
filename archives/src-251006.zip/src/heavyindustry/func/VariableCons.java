package heavyindustry.func;

public interface VariableCons<T> {
	@SuppressWarnings("unchecked")
	void apply(T... args);
}
