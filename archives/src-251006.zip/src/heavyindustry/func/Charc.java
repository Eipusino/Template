package heavyindustry.func;

public interface Charc {
	void get(char i);
}
