package heavyindustry.func;

public interface Longp {
	long get();
}
