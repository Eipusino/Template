package heavyindustry.func;

public interface Floatt<R> {
	R get(float param);
}
