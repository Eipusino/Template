package heavyindustry.func;

public interface Floatt3<R> {
	R get(float param1, float param2, float param3);
}
