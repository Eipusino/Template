package heavyindustry.func;

public interface Floatf2<A, B> {
	float get(A a, B b);
}
