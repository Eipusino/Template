package heavyindustry.func;

public interface BoolBoolf {
	boolean get(boolean value);
}
