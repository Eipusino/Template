package heavyindustry.func;

public interface DoubleDoublef {
	double get(double value);
}
