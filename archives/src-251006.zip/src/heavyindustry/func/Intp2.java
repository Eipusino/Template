package heavyindustry.func;

public interface Intp2<A, B> {
	int get(A a, B b);
}
