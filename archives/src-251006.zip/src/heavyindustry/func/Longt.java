package heavyindustry.func;

public interface Longt {
	long get(long value);
}
