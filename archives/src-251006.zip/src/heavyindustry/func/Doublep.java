package heavyindustry.func;

public interface Doublep {
	double get();
}
