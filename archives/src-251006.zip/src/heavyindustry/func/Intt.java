package heavyindustry.func;

public interface Intt {
	int get(int value);
}
