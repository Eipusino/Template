package heavyindustry.graphics;

import arc.Core;
import arc.files.Fi;
import arc.graphics.Color;
import arc.graphics.Texture;
import arc.graphics.Texture.TextureFilter;
import arc.graphics.Texture.TextureWrap;
import arc.graphics.g2d.TextureRegion;
import arc.graphics.g3d.Camera3D;
import arc.graphics.gl.Shader;
import arc.math.geom.Mat3D;
import arc.math.geom.Vec2;
import arc.math.geom.Vec3;
import arc.scene.ui.layout.Scl;
import arc.util.Time;
import arc.util.Tmp;
import heavyindustry.HVars;
import heavyindustry.type.AtmospherePlanet;
import mindustry.Vars;
import mindustry.type.Planet;

import static heavyindustry.HVars.MOD_NAME;

/**
 * Defines the {@linkplain Shader shader}s this mod offers.
 *
 * @author Eipusino
 */
public final class HShaders {
	public static DepthShader depth;
	public static DepthAtmosphereShader depthAtmosphere;
	public static AlphaShader alphaShader;
	public static HSurfaceShader brine, crystalFluid, deepCrystalFluid, boundWater, pit, waterPit;
	public static AberrationShader aberration;
	public static MaskShader alphaMask;
	public static WaveShader wave;
	public static MirrorFieldShader mirrorField;
	public static MaterializeShader materialize;
	public static VerticalBuildShader vertBuild;
	public static BlockBuildCenterShader blockBuildCenter;
	public static TractorConeShader tractorCone;
	public static DimShader dimShader;
	public static SmallSpaceShader smallSpaceShader;
	public static Shader distBase, passThrough;
	public static TilerShader tiler;
	public static PlanetTextureShader planetTexture;

	/** Don't let anyone instantiate this class. */
	private HShaders() {}

	/** Loads the shaders. */
	public static void load() {
		String prevVert = Shader.prependVertexCode, prevFrag = Shader.prependFragmentCode;
		Shader.prependVertexCode = Shader.prependFragmentCode = "";

		depth = new DepthShader();
		depthAtmosphere = new DepthAtmosphereShader();

		alphaShader = new AlphaShader();

		brine = new HSurfaceShader("general-highp", "brine");
		crystalFluid = new HSurfaceShader("general-highp", "crystal-fluid");
		deepCrystalFluid = new DualSurfaceShader("general-highp", "deep-crystal-fluid") {
			@Override
			public void loadNoise() {
				super.loadNoise();

				noiseTex2 = HTextures.darker;
				noiseTex = HTextures.smooth;
			}

			@Override
			public Texture getTexture() {
				return HTextures.smooth;
			}
		};
		boundWater = new HSurfaceShader("general-highp", "bound-water");
		pit = new PitShader("general-highp", "pit", MOD_NAME + "-concrete-blank1", MOD_NAME + "-stone-sheet", MOD_NAME + "-truss");
		waterPit = new PitShader("general-highp", "water-pit", MOD_NAME + "-concrete-blank1", MOD_NAME + "-stone-sheet", MOD_NAME + "-truss");

		aberration = new AberrationShader();

		alphaMask = new MaskShader();
		mirrorField = new MirrorFieldShader();
		wave = new WaveShader();

		materialize = new MaterializeShader();
		vertBuild = new VerticalBuildShader();
		blockBuildCenter = new BlockBuildCenterShader();
		tractorCone = new TractorConeShader();
		dimShader = new DimShader();
		smallSpaceShader = new SmallSpaceShader();

		distBase = new Shader(msv("general"), msf("dist-base"));
		passThrough = new Shader(msv("general-highp"), msf("pass-through"));

		tiler = new TilerShader();

		planetTexture = new PlanetTextureShader();

		Shader.prependVertexCode = prevVert;
		Shader.prependFragmentCode = prevFrag;
	}

	public static void dispose() {
		brine.dispose();
		crystalFluid.dispose();
		boundWater.dispose();
		pit.dispose();
		waterPit.dispose();
	}

	/**
	 * Resolves shader files from this mod via {@link Vars#tree}.
	 *
	 * @param name The shader file name, e.g. {@code my-shader.frag}.
	 * @return The shader file, located inside {@code shaders/}.
	 */
	public static Fi dsf(String name) {
		return Core.files.internal("shaders/" + name + ".frag");
	}

	public static Fi dsv(String name) {
		return Core.files.internal("shaders/" + name + ".vert");
	}

	public static Fi msf(String name) {
		return HVars.internalTree.child("shaders/" + name + ".frag");
	}

	public static Fi msv(String name) {
		return HVars.internalTree.child("shaders/" + name + ".vert");
	}

	/** Specialized mesh shader to capture fragment depths. */
	public static class DepthShader extends Shader {
		public Camera3D camera;

		/** The only instance of this class: {@link #depth}. */
		DepthShader() {
			super(msv("depth"), msf("depth"));
		}

		@Override
		public void apply() {
			setUniformf("u_camPos", camera.position);
			setUniformf("u_camRange", camera.near, camera.far - camera.near);
		}
	}

	/**
	 * An atmosphere shader that incorporates the planet shape in a form of depth texture. Better quality, but at the little
	 * cost of performance.
	 */
	public static class DepthAtmosphereShader extends Shader {
		private static final Mat3D mat = new Mat3D();

		public Camera3D camera;
		public AtmospherePlanet planet;

		/** The only instance of this class: {@link #depthAtmosphere}. */
		DepthAtmosphereShader() {
			super(msv("depth-atmosphere"), msf("depth-atmosphere"));
		}

		@Override
		public void apply() {
			setUniformMatrix4("u_proj", camera.combined.val);
			setUniformMatrix4("u_trans", planet.getTransform(mat).val);

			setUniformf("u_camPos", camera.position);
			setUniformf("u_relCamPos", Tmp.v31.set(camera.position).sub(planet.position));
			setUniformf("u_camRange", camera.near, camera.far - camera.near);
			setUniformf("u_center", planet.position);
			setUniformf("u_light", planet.getLightNormal());
			setUniformf("u_color", planet.atmosphereColor.r, planet.atmosphereColor.g, planet.atmosphereColor.b);

			setUniformf("u_innerRadius", planet.radius + planet.atmosphereRadIn);
			setUniformf("u_outerRadius", planet.radius + planet.atmosphereRadOut);

			planet.buffer.getTexture().bind(0);
			setUniformi("u_topology", 0);
			setUniformf("u_viewport", Core.graphics.getWidth(), Core.graphics.getHeight());
		}
	}

	public static class PlanetTextureShader extends Shader {
		public Vec3 lightDir = new Vec3(1, 1, 1).nor();
		public Color ambientColor = Color.white.cpy();
		public Vec3 camDir = new Vec3();
		public float alpha = 1f;
		public Planet planet;

		/** The only instance of this class: {@link #planetTexture}. */
		PlanetTextureShader() {
			super(msv("circle-mesh"), msf("circle-mesh"));
		}

		@Override
		public void apply() {
			camDir.set(Vars.renderer.planets.cam.direction).rotate(Vec3.Y, planet.getRotation());

			setUniformf("u_alpha", alpha);
			setUniformf("u_lightdir", lightDir);
			setUniformf("u_ambientColor", ambientColor.r, ambientColor.g, ambientColor.b);
			setPlanetInfo("u_sun_info", planet.solarSystem);
			setPlanetInfo("u_planet_info", planet);
			setUniformf("u_camdir", camDir);
			setUniformf("u_campos", Vars.renderer.planets.cam.position);
		}

		private void setPlanetInfo(String name, Planet planet) {
			Vec3 position = planet.position;
			setUniformf(name, position.x, position.y, position.z, planet.radius);
		}
	}

	public static class TilerShader extends Shader {
		public Texture texture = Core.atlas.white().texture;
		public float scl = 4f;

		/** The only instance of this class: {@link #tiler}. */
		TilerShader() {
			super(msv("general-highp"), msf("tiler"));
		}

		@Override
		public void apply() {
			setUniformf("u_offset", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_texsize", Core.camera.width, Core.camera.height);
			setUniformf("u_tiletexsize", texture.width / scl, texture.height / scl);

			texture.bind(1);
			Vars.renderer.effectBuffer.getTexture().bind(0);

			setUniformi("u_tiletex", 1);
		}
	}

	public static class AlphaShader extends Shader {
		public float alpha = 1f;

		/** The only instance of this class: {@link #alphaShader}. */
		AlphaShader() {
			super(msv("general-highp"), msf("post-alpha"));
		}

		@Override
		public void apply() {
			setUniformf("u_alpha", alpha);
		}
	}

	public static class WaveShader extends Shader {
		public Color waveMix = Color.white;
		public float mixAlpha = 0.4f;
		public float mixOmiga = 0.75f;
		public float maxThreshold = 0.9f;
		public float minThreshold = 0.6f;
		public float waveScl = 0.2f;

		/** The only instance of this class: {@link #wave}. */
		WaveShader() {
			super(msv("general-highp"), msf("wave"));
		}

		@Override
		public void apply() {
			setUniformf("u_campos", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_resolution", Core.camera.width, Core.camera.height);
			setUniformf("u_time", Time.time);

			setUniformf("mix_color", waveMix);
			setUniformf("mix_alpha", mixAlpha);
			setUniformf("mix_omiga", mixOmiga);
			setUniformf("wave_scl", waveScl);
			setUniformf("max_threshold", maxThreshold);
			setUniformf("min_threshold", minThreshold);
		}
	}

	public static class MirrorFieldShader extends Shader {
		public Color waveMix = Color.white;
		public Vec2 offset = new Vec2(0, 0);
		public float stroke = 2;
		public float gridStroke = 0.8f;
		public float mixAlpha = 0.4f;
		public float alpha = 0.2f;
		public float maxThreshold = 1;
		public float minThreshold = 0.7f;
		public float waveScl = 0.03f;
		public float sideLen = 10;

		/** The only instance of this class: {@link #mirrorField}. */
		MirrorFieldShader() {
			super(msv("general-highp"), msf("mirror-field"));
		}

		@Override
		public void apply() {
			setUniformf("u_campos", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_resolution", Core.camera.width, Core.camera.height);
			setUniformf("u_time", Time.time);

			setUniformf("offset", offset);
			setUniformf("u_step", stroke);
			setUniformf("mix_color", waveMix);
			setUniformf("mix_alpha", mixAlpha);
			setUniformf("u_stroke", gridStroke);
			setUniformf("u_alpha", alpha);
			setUniformf("wave_scl", waveScl);
			setUniformf("max_threshold", maxThreshold);
			setUniformf("min_threshold", minThreshold);
			setUniformf("side_len", sideLen);
		}
	}

	public static final class MaskShader extends Shader {
		public Texture texture;

		/** The only instance of this class: {@link #alphaMask}. */
		MaskShader() {
			super(msv("general"), msf("alpha-mask"));
		}

		@Override
		public void apply() {
			setUniformi("u_texture", 1);
			setUniformi("u_mask", 0);

			texture.bind(1);
		}
	}

	public static final class AberrationShader extends Shader {
		AberrationShader() {
			super(msv("general"), msf("aberration"));
		}

		@Override
		public void apply() {
			setUniformf("u_dp", Scl.scl(1f));
			setUniformf("u_time", Time.time / Scl.scl(1f));
			setUniformf("u_offset",
					Core.camera.position.x - Core.camera.width / 2,
					Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_texsize", Core.camera.width, Core.camera.height);
		}
	}

	public static class MaterializeShader extends Shader {
		public float progress, offset, time;
		public int shadow;
		public Color color = new Color();
		public TextureRegion region;

		MaterializeShader() {
			super(msv("materialize"), msf("materialize"));
		}

		@Override
		public void apply() {
			setUniformf("u_progress", progress);
			setUniformf("u_offset", offset);
			setUniformf("u_time", time);
			setUniformf("u_width", region.width);
			setUniformf("u_shadow", shadow);
			setUniformf("u_color", color);
			setUniformf("u_uv", region.u, region.v);
			setUniformf("u_uv2", region.u2, region.v2);
			setUniformf("u_texsize", region.texture.width, region.texture.height);
		}
	}

	public static class VerticalBuildShader extends Shader {
		public float progress, time;
		public Color color = new Color();
		public TextureRegion region;

		VerticalBuildShader() {
			super(msv("vertical-build"), msf("vertical-build"));
		}

		@Override
		public void apply() {
			setUniformf("u_time", time);
			setUniformf("u_color", color);
			setUniformf("u_progress", progress);
			setUniformf("u_uv", region.u, region.v);
			setUniformf("u_uv2", region.u2, region.v2);
			setUniformf("u_texsize", region.texture.width, region.texture.height);
		}
	}

	public static class BlockBuildCenterShader extends Shader {
		public float progress;
		public TextureRegion region;
		public float time;

		BlockBuildCenterShader() {
			super(msv("block-build-center"), msf("block-build-center"));
		}

		@Override
		public void apply() {
			setUniformf("u_progress", progress);
			setUniformf("u_uv", region.u, region.v);
			setUniformf("u_uv2", region.u2, region.v2);
			setUniformf("u_time", time);
			setUniformf("u_texsize", region.texture.width, region.texture.height);
		}
	}

	public static class TractorConeShader extends Shader {
		public float cx, cy;
		public float time, spacing, thickness;

		TractorConeShader() {
			super(msv("general-highp"), msf("tractor-cone"));
		}

		@Override
		public void apply() {
			setUniformf("u_dp", Scl.scl(1f));
			setUniformf("u_time", time / Scl.scl(1f));
			setUniformf("u_offset",
					Core.camera.position.x - Core.camera.width / 2,
					Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_texsize", Core.camera.width, Core.camera.height);

			setUniformf("u_spacing", spacing / Scl.scl(1f));
			setUniformf("u_thickness", thickness / Scl.scl(1f));
			setUniformf("u_cx", cx / Scl.scl(1f));
			setUniformf("u_cy", cy / Scl.scl(1f));
		}

		public void setCenter(float x, float y) {
			cx = x;
			cy = y;
		}
	}

	public static class DimShader extends Shader {
		public float alpha;

		DimShader() {
			super(msv("general"), msf("dim"));
		}

		@Override
		public void apply() {
			setUniformf("u_alpha", alpha);
		}
	}

	public static class SmallSpaceShader extends Shader {
		Texture texture;

		SmallSpaceShader() {
			super(msv("general-highp"), msf("small-space"));
		}

		@Override
		public void apply() {
			if (texture == null) {
				texture = new Texture(HVars.internalTree.child("other/textures/small-space.png"));
				texture.setFilter(TextureFilter.linear);
				texture.setWrap(TextureWrap.repeat);
			}

			setUniformf("u_campos", Core.camera.position.x, Core.camera.position.y);
			setUniformf("u_ccampos", Core.camera.position);
			setUniformf("u_resolution", Core.graphics.getWidth(), Core.graphics.getHeight());
			setUniformf("u_time", Time.time);

			texture.bind(1);
			Vars.renderer.effectBuffer.getTexture().bind(0);

			setUniformi("u_stars", 1);
		}
	}

	/** SurfaceShader but uses a mod fragment asset. */
	public static class PitShader extends HSurfaceShader {
		protected TextureRegion topLayer, bottomLayer, truss;
		protected String topLayerName, bottomLayerName, trussName;

		public PitShader(String vertex, String fragment, String topLayer, String bottomLayer, String truss) {
			super(vertex, fragment);
			topLayerName = topLayer;
			bottomLayerName = bottomLayer;
			trussName = truss;
		}

		@Override
		public void apply() {
			Texture texture = Core.atlas.find("grass1").texture;
			if (topLayer == null)
				topLayer = Core.atlas.find(topLayerName);

			if (bottomLayer == null)
				bottomLayer = Core.atlas.find(bottomLayerName);

			if (truss == null)
				truss = Core.atlas.find(trussName);

			if (noiseTex == null)
				noiseTex = Core.assets.get("sprites/" + textureName() + ".png", Texture.class);

			setUniformf("u_campos", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_resolution", Core.camera.width, Core.camera.height);
			setUniformf("u_time", Time.time);

			setUniformf("u_toplayer", topLayer.u, topLayer.v, topLayer.u2, topLayer.v2);
			setUniformf("u_bottomlayer", bottomLayer.u, bottomLayer.v, bottomLayer.u2, bottomLayer.v2);
			setUniformf("bvariants", bottomLayer.width / 32f);
			setUniformf("u_truss", truss.u, truss.v, truss.u2, truss.v2);

			texture.bind(2);
			noiseTex.bind(1);
			Vars.renderer.effectBuffer.getTexture().bind(0);
			setUniformi("u_noise", 1);
			setUniformi("u_texture2", 2);
		}
	}

	public static class DualSurfaceShader extends HSurfaceShader {
		protected Texture noiseTex2;

		public DualSurfaceShader(String vertex, String fragment) {
			super(vertex, fragment);
		}

		public Texture getTexture() {
			return null;
		}

		@Override
		public void apply() {
			setUniformf("u_campos", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_resolution", Core.camera.width, Core.camera.height);
			setUniformf("u_time", Time.time);

			if (hasUniform("u_noise")) {
				if (noiseTex == null) {
					noiseTex = getTexture() == null ? Core.assets.get("sprites/" + textureName() + ".png", Texture.class) : getTexture();
				}

				noiseTex.bind(1);
				Vars.renderer.effectBuffer.getTexture().bind(0);

				setUniformi("u_noise", 1);
			}

			if (hasUniform("u_noise_2")) {
				if (noiseTex2 == null) {
					noiseTex2 = Core.assets.get("sprites/" + "noise" + ".png", Texture.class);
				}

				noiseTex2.bind(1);
				Vars.renderer.effectBuffer.getTexture().bind(0);

				setUniformi("u_noise_2", 1);
			}
		}
	}

	public static class HSurfaceShader extends Shader {
		protected Texture noiseTex;

		public HSurfaceShader(String vertex, String fragment) {
			super(msv(vertex), msf(fragment));
			loadNoise();
		}

		public String textureName() {
			return "noise";
		}

		public void loadNoise() {
			Core.assets.load("sprites/" + textureName() + ".png", Texture.class).loaded = t -> {
				t.setFilter(TextureFilter.linear);
				t.setWrap(TextureWrap.repeat);
			};
		}

		@Override
		public void apply() {
			setUniformf("u_campos", Core.camera.position.x - Core.camera.width / 2, Core.camera.position.y - Core.camera.height / 2);
			setUniformf("u_resolution", Core.camera.width, Core.camera.height);
			setUniformf("u_time", Time.time);

			if (hasUniform("u_noise")) {
				if (noiseTex == null) {
					noiseTex = Core.assets.get("sprites/" + textureName() + ".png", Texture.class);
				}

				noiseTex.bind(1);
				Vars.renderer.effectBuffer.getTexture().bind(0);

				setUniformi("u_noise", 1);
			}
		}
	}
}
