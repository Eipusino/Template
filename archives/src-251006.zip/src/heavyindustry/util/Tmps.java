package heavyindustry.util;

@Deprecated
public final class Tmps {
	private Tmps() {}
}
